Quantum Image Compression with D-Wave QPU
This project demonstrates a proof-of-concept implementation of image compression using quantum annealing,
leveraging the D-Wave Quantum Processing Unit (QPU). It uses a simplified K-Means clustering approach to compress
image colors by converting the clustering task into a QUBO (Quadratic Unconstrained Binary Optimization) problem 
solvable by D-Wave.

 Project Highlights
 Compresses RGB color space of an image using quantum annealing.

 Reformulates clustering as a QUBO optimization problem.

 Utilizes D-Wave Ocean SDK and the quantum cloud platform.

 Experimental technique using simplified clustering logic and quantum optimization.

Technologies & Libraries
Python 3.x

OpenCV (cv2)

NumPy

Scikit-learn

D-Wave Ocean SDK

 File Structure
bash
Copy
Edit
.
├── quantum_image_compression.py     # Main script
├── myPhoto.jpg                      # Input image (user-supplied)
├── compressed_image.png             # Output (quantum-compressed image)
├── K_Mean_Clustering_image_compress_.ipynb  # Jupyter notebook (optional)
├── README.md                        # Project documentation
⚙ Installation
Install the required libraries:

bash
Copy
Edit
pip install opencv-python numpy scikit-learn dwave-ocean-sdk
Set up your D-Wave Leap API token:

bash
Copy
Edit
dwave config create
Follow the prompts and input your D-Wave API token. You can get this from the D-Wave Leap portal.

🚀 How It Works
Load & Resize: The image is loaded and resized to 64x64 for tractable processing on the QPU.

Flatten & Normalize: RGB values are normalized and flattened for clustering.

QUBO Formulation: A distance-based QUBO matrix is constructed, favoring similar colors to form clusters.

Quantum Sampling: D-Wave's QPU minimizes the QUBO to find low-energy solutions representing color clusters.

Reconstruction: The best quantum sample is used to assign compressed RGB values and reconstruct the image.

🖥️ How to Run
Replace myPhoto.jpg with your own image.

Run the script:

bash
Copy
Edit
python quantum_image_compression.py
This will generate compressed_image.png as the output.

📉 Example Image Clustering
Original vs Compressed (Color-Space Clustered)
<img src="https://via.placeholder.com/300x100.png?text=Original+and+Compressed+Images" alt="Original vs Compressed"
width="600"/>
(Replace with actual comparison image or upload screenshots to GitHub)

Code Overview
QUBO Generation Logic
python
Copy
Edit
for i in range(n):
    for j in range(i + 1, n):
        distance = np.linalg.norm(data[i] - data[j])
        Q[i, j] = Q[j, i] = distance
Quantum Sampling
python
Copy
Edit
sampler = DWaveSampler()
embedding = EmbeddingComposite(sampler)
response = embedding.sample_qubo(Q, num_reads=100)
Limitations
This is a simplified model; cluster exclusivity and centroids are approximated.

Best for small images due to QPU limits.

Requires access to the D-Wave Leap cloud for execution.

Future Improvements
Implement strict one-hot encoding for accurate cluster assignments.
Integrate classical post-processing for cluster refinement.
Use hybrid quantum-classical samplers for scalability.

This project demonstrates how quantum computing, particularly D-Wave's quantum annealer, can be applied to
solve classical combinatorial optimization problems like the 0/1 Knapsack problem. By formulating the problem
as a QUBO (Quadratic Unconstrained Binary Optimization), we leverage quantum resources to explore a massive 
solution space efficiently.

While this implementation is limited by the scale of the current quantum hardware and the simplicity of our
formulation, it opens the door to a future where quantum-accelerated optimization becomes a powerful tool in
logistics, finance, and resource allocation tasks.

In summary: Quantum optimization offers a novel and potentially game-changing approach to solving NP-hard problems,
and this knapsack example provides a practical foundation to explore that potential.



